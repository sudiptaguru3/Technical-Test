<?php

class DashboardModel extends CI_Model{
    public function get_data($id=0)
    {
        if($id==0)
        {
            $query = $this->db->get('dashboarddata')->result();
            return $query;
        }
        else
        {
            $this->db->where('id',$id);
            $query = $this->db->get('dashboarddata')->result();
            return $query;
        }
        
    }
}

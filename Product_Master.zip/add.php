<?php
require_once("dbcontroller.php");
$db_handle = new DBController();
if(!empty($_POST["submit"])) {
    $query = "INSERT INTO product_master(product_name, product_cost, quantity, rate) VALUES('".$_POST["product_name"]."','".$_POST["product_cost"]."','".$_POST["quantity"]."','".$_POST["rate"]."')";
        $result = $db_handle->executeQuery($query);
    if(!$result){
			$message="Problem in Adding to database. Please Retry.";
	} else {
		header("Location:index.php");
	}
}
?>
<link href="style.css" type="text/css" rel="stylesheet" />
<script src="https://code.jquery.com/jquery-2.1.1.min.js" type="text/javascript"></script>
<script>
function validate() {
	var valid = true;	
	$(".demoInputBox").css('background-color','');
	$(".info").html('');
	
	if(!$("#product_name").val()) {
		$("#product_name-info").html("(required)");
		$("#product_name").css('background-color','#FFFFDF');
		valid = false;
	}
	if(!$("#product_cost").val()) {
		$("#product_cost-info").html("(required)");
		$("#product_cost").css('background-color','#FFFFDF');
		valid = false;
	}
	if(!$("#quantity").val()) {
		$("#quantity-info").html("(required)");
		$("#quantity").css('background-color','#FFFFDF');
		valid = false;
	}
	if(!$("#rate").val()) {
		$("#rate-info").html("(required)");
		$("#rate").css('background-color','#FFFFDF');
		valid = false;
	}	
	return valid;
}
</script>
<form name="frmToy" method="post" action="" id="frmToy" onClick="return validate();">
<div id="mail-status"></div>
<div>
<label style="padding-top:20px;">Product Name</label>
<span id="product_name-info" class="info"></span><br/>
<input type="text" name="product_name" id="product_name" class="demoInputBox">
</div>
<div>
<label>Product Cost</label>
<span id="product_cost-info" class="info"></span><br/>
<input type="text" name="product_cost" id="product_cost" class="demoInputBox">
</div>
<div>
<label>Quantity</label> 
<span id="quantity-info" class="info"></span><br/>
<input type="text" name="quantity" id="quantity" class="demoInputBox">
</div>
<div>
<label>Rate</label> 
<span id="rate-info" class="info"></span><br/>
<input type="text" name="rate" id="rate" class="demoInputBox">
</div>
<div>
<input type="submit" name="submit" id="btnAddAction" value="Add" />
</div>
</form>
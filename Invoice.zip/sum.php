
<?php
//servername
$servername = "db5004538553.hosting-data.io";
//username
$username = "dbu325373";
//empty password
$password = "mRl4@kfhjyRs";
//geek is the database name
$dbname = "dbs3792002";
  
// Create connection by passing these connection parameters
$conn = new mysqli($servername, $username, $password, $dbname);
  
//sql query to find average cost of food items in food table
$sql = "SELECT  SUM(total) FROM invoice";
$result2 = $conn->query($sql);
//display data on web page
while($row = mysqli_fetch_array($result2)){
    echo "<b>Grand Total :</b>". $row['SUM(total)'];
      echo "<br />";
}
  
//close the connection
  
$conn->close();
?>

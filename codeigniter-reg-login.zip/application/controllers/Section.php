<?php

defined('BASEPATH') OR exit('No direct script access allowed');

class Section extends MY_Controller {
	public function __construct() {
        parent::__construct();
        
        //load the required helpers and libraries
        $this->load->helper('url');
        $this->load->library(['form_validation', 'session']);
        $this->load->database();
        
        $this->load->model('DashboardModel', 'dashboard');
    }

    public function index() {
        $sidenavbar['test']=$this->dashboard->get_data();
        $this->load->view('viewSection',$sidenavbar);
    }

}

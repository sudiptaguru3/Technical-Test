<?php
class DBController {
	private $host = "localhost";
	private $user = "root";
	private $password = "";
	private $database = "dbs3792002";
    private $conn;
	
	function __construct() {
		$this->conn = $this->connectDB();
	}
	
	function connectDB() {
		try{
		$conn = mysqli_connect($this->host,$this->user,$this->password,$this->database);
		return $conn;
		}catch(Exception $e){
			echo $e->message;
		}
	}
	
	function runQuery($query) {
		$result = mysqli_query($this->conn,$query)or die(mysqli_error($this->conn));
		while($row=mysqli_fetch_assoc($result)) {
			$resultset[] = $row;
		}		
		if(!empty($resultset))
			return $resultset;
	}
	
	function numRows($query) {
		$result  = mysqli_query($this->conn, $query);
		$rowcount = mysqli_num_rows($result);
		return $rowcount;	
	}
	
	function executeQuery($query) {
	    $result  = mysqli_query($this->conn, $query);
	    return $result;	
	}
}
?>

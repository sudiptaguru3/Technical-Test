<?php

  $i=1;
  foreach ($test as $row)
    {
      $id=$row->id;

                       
?>
<nav class="side-navbar">
      <div class="side-navbar-wrapper">
        <!-- Sidebar Header    -->
        <div class="sidenav-header d-flex align-items-center justify-content-center">
          <!-- User Info-->
          <div class="sidenav-header-inner text-center">
            <h2 class="h5"><?php echo $row->name;?></h2><span><?php echo $row->position;?></span>
          </div>
          <!-- Small Brand information, appears on minimized sidebar-->
          <div class="sidenav-header-logo"><a href="index.html" class="brand-small text-center"> </a></div>
        </div>
        <!-- Sidebar Navigation Menus-->
        <div class="main-menu">
          <h5 class="sidenav-heading"><?php echo $row->main;?></h5>
          <ul id="side-main-menu" class="side-menu list-unstyled">                  
            <li><a href="#"> <i class="icon-home"></i><?php echo $row->home;?></a></li>
            <li><a href="#"> <i class="icon-form"></i><?php echo $row->forms;?></a></li>
            <li><a href="#"> <i class="fa fa-bar-chart"></i><?php echo $row->charts;?>                             </a></li>
            <li><a href="#"> <i class="icon-grid"></i><?php echo $row->tables;?></a></li>
            <li><a href="#exampledropdownDropdown" aria-expanded="false" data-toggle="collapse"> <i class="icon-interface-windows"></i><?php echo $row->example_dropdown;?></a>
              <ul id="exampledropdownDropdown" class="collapse list-unstyled ">
                <li><a href="Section/index"><?php echo $row->page1;?></a></li>
                <li><a href="#"><?php echo $row->page2;?></a></li>
              </ul>
            </li>
          </ul>
        </div>
       
      </div>
    </nav>
    <?php 
      $i++;
      }
    ?>
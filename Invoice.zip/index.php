<?php
	require_once("perpage.php");	
	require_once("dbcontroller.php");
	$db_handle = new DBController();
	
	$name = "";
	$code = "";
	
	$queryCondition = "";
	
	$orderby = " ORDER BY id desc"; 
	$sql = "SELECT * FROM invoice " . $queryCondition;
	$sql1 = "SELECT sum(total) FROM invoice " . $queryCondition;
	// $sql2 = "SELECT product_cost FROM product_master " . $queryCondition;
	// $sql3 = "SELECT quantity FROM product_master " . $queryCondition;
	$href = 'index.php';				
		
	$perPage = 2; 
	$page = 1;
	if(isset($_POST['page'])){
		$page = $_POST['page'];
	}
	$start = ($page-1)*$perPage;
	if($start < 0) $start = 0;
		
	$query =  $sql . $orderby .  " limit " . $start . "," . $perPage; 
	$result = $db_handle->runQuery($query);

	// $query1 =  $sql1 . $orderby .  " limit " . $start . "," . $perPage;
	// $result1 = $db_handle->runQuery($query1);

	// $n1 =  $sql2 . $orderby .  " limit " . $start . "," . $perPage;
	// $result2 = $db_handle->runQuery($n1);
	// $n2 =  $sql3 . $orderby .  " limit " . $start . "," . $perPage;
	// $result3 = $db_handle->runQuery($n2);
	// $data = $n1*$n2;
	
	if(!empty($result)) {
		$result["perpage"] = showperpage($sql, $perPage, $href);
	}
	// print_r($data);


?>

<html>
	<head>
	<title>Invoice</title>
	<link href="style.css" type="text/css" rel="stylesheet" />
	</head>
	<body>
		<h2>Invoice</h2>
		            <?php
		            // $data = print_r($result1);
		            // echo json_encode($result1);
		            include("sum.php");
					?>
					
		
		<div style="text-align:right;margin:20px 0px 10px;">
		<a id="btnAddAction" href="add.php">Add New</a>
		</div>
    <div id="toys-grid">      
			<form name="frmSearch" method="post" action="index.php">
			<div class="search-box">
			
			</div>
			
			<table cellpadding="10" cellspacing="1">
        <thead>
					<tr>
          <th><strong>Invoice Number</strong></th>
          <th><strong>Product Name</strong></th>          
          <th><strong>Quantity</strong></th>
	      <th><strong>Rate</strong></th>
	      <th><strong>Total</strong></th>
					
					</tr>
				</thead>
				<tbody>
					<?php
					if(!empty($result)) {
						foreach($result as $k=>$v) {
						  if(is_numeric($k)) {
					?>
          <tr>
					<td>A000<?php echo $result[$k]["id"]; ?></td>
          <td><?php echo $result[$k]["product_name"]; ?></td>
					<td><?php echo $result[$k]["quantity"]; ?></td>
					<td><?php echo $result[$k]["rate"]; ?></td>
					<td><?php echo $result[$k]["total"]; ?></td>
					</tr>
					<?php
						  }
					   }
                    }
					if(isset($result["perpage"])) {
					?>
					<tr>
					<td colspan="6" align=right> <?php echo $result["perpage"]; ?></td>
					</tr>
					<?php } ?>
				<tbody>
			</table>
			</form>	
		</div>
	</body>
</html>
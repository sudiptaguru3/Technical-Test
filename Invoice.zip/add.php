<?php
require_once("dbcontroller.php");
$db_handle = new DBController();
if(!empty($_POST["submit"])) {
    $query = "INSERT INTO invoice(product_name, quantity, rate, total) VALUES('".$_POST["product_name"]."','".$_POST["quantity"]."','".$_POST["rate"]."','".$_POST["total"]."')";
        $result = $db_handle->executeQuery($query);
    if(!$result){
			$message="Problem in Adding to database. Please Retry.";
	} else {
		header("Location:index.php");
	}
}
?>
<link href="style.css" type="text/css" rel="stylesheet" />
<script src="https://code.jquery.com/jquery-2.1.1.min.js" type="text/javascript"></script>
<script>
function validate() {
	var valid = true;	
	$(".demoInputBox").css('background-color','');
	$(".info").html('');

    
	if(!$("#product_name").val()) {
		$("#product_name-info").html("(required)");
		$("#product_name").css('background-color','#FFFFDF');
		valid = false;
	}
	if(!$("#quantity").val()) {
		$("#quantity-info").html("(required)");
		$("#quantity").css('background-color','#FFFFDF');
		valid = false;
	}
	if(!$("#rate").val()) {
		$("#rate-info").html("(required)");
		$("#rate").css('background-color','#FFFFDF');
		valid = false;
	}	
	if(!$("#total").val()) {
		$("#total-info").html("(required)");
		$("#total").css('background-color','#FFFFDF');
		valid = false;
	}	
	return valid;
}
</script>
<form name="frmToy" method="post" action="" id="frmToy" onClick="return validate();">
<div id="mail-status"></div>
<div>
<label>Product Name</label>
<span id="product_name-info" class="info"></span><br/>
<select name="product_name" id="product_name" class="demoInputBox">
	<option value="samsung">Samsung</option>
	<option value="vivo">Vivo</option>
	<option value="oppo">Oppo</option>
</select>
</div>
<div>
<label>Quantity</label> 
<span id="quantity-info" class="info"></span><br/>
<input type="text" name="quantity" id="quantity" class="demoInputBox">
</div>
<div>
<label>Rate</label> 
<span id="rate-info" class="info"></span><br/>
<input type="text" name="rate" id="rate" class="demoInputBox">
</div>
<div>
<label>Total</label> 
<span id="total-info" class="info"></span><br/>
<input type="text" name="total" id="total" class="demoInputBox">
</div>
<div>
<input type="submit" name="submit" id="btnAddAction" value="Add" />
</div>
</form>
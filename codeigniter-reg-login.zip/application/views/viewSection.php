<!DOCTYPE html>
<html>
  <head>
    <?php include 'include/headercss.php';?>
  </head>
  <body>
    <!-- Side Navbar -->
    <?php include 'include/sidenavbar.php';?>
    <div class="page">
      <!-- navbar-->
      <header class="header">
        <?php include 'include/navbar.php';?>
      </header>
      <!-- Counts Section -->
     
      <!-- Header Section-->
     
      <!-- Statistics Section-->
      
      <!-- Updates Section -->
      <section class="mt-30px mb-30px">
        <div class="card-body">
                  <div class="table-responsive">
                    <table class="table">
                      <thead>
                        <tr>
                          <th>#</th>
                          <th>Name</th>
                          <th>Position</th>
                          <th>Main</th>
                          <th>Home</th>
                          <th>Forms</th>
                          <th>Charts</th>
                          <th>Tables</th>
                          <th>Example Dropdown</th>
                          <th>Page1</th>
                          <th>Page2</th>
                          <th>Bootstrap</th>
                          <th>Dashboard</th>
                          <th>Content</th>
                          <th>Logout</th>
                          <th>Action</th>
                        </tr>
                      </thead>
                      <tbody>
                        <tr>
                          <th scope="row">1</th>
                          <td>Mark</td>
                          <td>Otto</td>
                          <td>@mdo</td>
                          <td>Mark</td>
                          <td>Otto</td>
                          <td>@mdo</td>
                          <td>Mark</td>
                          <td>Otto</td>
                          <td>@mdo</td>
                          <td>Mark</td>
                          <td>Otto</td>
                          <td>@mdo</td>
                          <td>Mark</td>
                          <td>Otto</td>
                          <td>Otto</td>
                        </tr>
                      </tbody>
                    </table>
                  </div>
                </div>
      </section>
      
    </div>
    <?php include 'include/footerjs.php';?>
  </body>
</html>
<!DOCTYPE html>
<html>
  <head>
    <?php include 'include/headercss.php';?>
  </head>
  <body>
    <!-- Side Navbar -->
    <?php include 'include/sidenavbar.php';?>
    <div class="page">
      <!-- navbar-->
      <header class="header">
        <?php include 'include/navbar.php';?>
      </header>
      <!-- Counts Section -->
     
      <!-- Header Section-->
     
      <!-- Statistics Section-->
      
      <!-- Updates Section -->
      <section class="mt-30px mb-30px">
        <?php

          $i=1;
          foreach ($test as $row)
            {
              $id=$row->id;

                       
        ?>
      <?php echo $row->content;?>
      <?php 
        $i++;
        }
      ?>
      </section>
      
    </div>
    <?php include 'include/footerjs.php';?>
  </body>
</html>
-- phpMyAdmin SQL Dump
-- version 5.0.2
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1
-- Generation Time: Dec 07, 2021 at 06:07 AM
-- Server version: 10.4.11-MariaDB
-- PHP Version: 7.4.4

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `codeigniter`
--

-- --------------------------------------------------------

--
-- Table structure for table `dashboarddata`
--

CREATE TABLE `dashboarddata` (
  `id` int(11) NOT NULL,
  `name` varchar(255) NOT NULL,
  `position` varchar(255) NOT NULL,
  `main` varchar(255) NOT NULL,
  `home` varchar(255) NOT NULL,
  `forms` varchar(255) NOT NULL,
  `charts` varchar(255) NOT NULL,
  `tables` varchar(255) NOT NULL,
  `example_dropdown` varchar(255) NOT NULL,
  `page1` varchar(255) NOT NULL,
  `page2` varchar(255) NOT NULL,
  `bootstrap` varchar(255) NOT NULL,
  `dashboard` varchar(255) NOT NULL,
  `logout` varchar(255) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `dashboarddata`
--

INSERT INTO `dashboarddata` (`id`, `name`, `position`, `main`, `home`, `forms`, `charts`, `tables`, `example_dropdown`, `page1`, `page2`, `bootstrap`, `dashboard`, `logout`) VALUES
(1, 'Sudipta Guru', 'Web Developer', 'Main', 'Home', 'Forms', 'Charts', 'Tables', 'Example dropdown', 'Page1', 'Page2', 'Bootstrap', 'Dashboard', 'Logout');

-- --------------------------------------------------------

--
-- Table structure for table `users`
--

CREATE TABLE `users` (
  `user_id` int(11) NOT NULL,
  `name` varchar(100) NOT NULL,
  `email` varchar(100) NOT NULL,
  `password` varchar(50) NOT NULL,
  `date_time` datetime NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `users`
--

INSERT INTO `users` (`user_id`, `name`, `email`, `password`, `date_time`) VALUES
(1, 'Sudipta Guru', 'sudiptaguru@gmail.com', '7c4a8d09ca3762af61e59520943dc26494f8941b', '2021-12-06 19:04:36');

--
-- Indexes for dumped tables
--

--
-- Indexes for table `dashboarddata`
--
ALTER TABLE `dashboarddata`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `users`
--
ALTER TABLE `users`
  ADD PRIMARY KEY (`user_id`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `dashboarddata`
--
ALTER TABLE `dashboarddata`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=2;

--
-- AUTO_INCREMENT for table `users`
--
ALTER TABLE `users`
  MODIFY `user_id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=2;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
